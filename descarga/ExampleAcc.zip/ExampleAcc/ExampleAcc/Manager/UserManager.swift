//
//  UserManager.swift
//  ExampleAcc
//
//  Created by Dambert Louis Munoz Santillana on 18/05/22.
//

import Foundation

class UserManager {

    // MARK: Properties
    /// Singleton
    static let shared = UserManager()
    /// Arreglo de usuarios
    var arreglo: [User] = []

    // MARK: Inits
    init() {

    }

    // MARK: Methods
    func add(user: User) {
        arreglo.append(user)
    }

    func remove(index: Int) {
        arreglo.remove(at: index)
    }

}
