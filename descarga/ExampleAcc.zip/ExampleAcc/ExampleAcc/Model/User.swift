//
//  User.swift
//  ExampleAcc
//
//  Created by Dambert Louis Munoz Santillana on 18/05/22.
//

import Foundation

enum UserType: String {
    case vip
    case promo
    case normal
}

struct User {
    // MARK: Properties
    var username: String
    var password: String
    var edad: Int
    var numeroHijos: Int
    var type: UserType
}

