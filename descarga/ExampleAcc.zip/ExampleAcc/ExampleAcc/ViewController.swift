//
//  ViewController.swift
//  ExampleAcc
//
//  Created by Dambert Louis Munoz Santillana on 18/05/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func onTapAdd(_ sender: Any) {

        guard let usernameText = usernameTextField.text, usernameText.count > 0 else {
            // Show Alert
            return
        }

        guard let passwordText = passwordTextField.text,
              passwordText.count > 0 else {
            // Show Alert
            return
        }

//        {
//            "username" : "nombre",
//            "password": "asdasdasd1asdasda",
//            "rol": "vip" // "premium" "normal" "usuariosDeAltoNivel"
//
//        }

        // UserType(rawValue: "usuariosDeAltoNivel")

        let user = User(username: usernameText, password: passwordText, edad: 20, numeroHijos: 27, type: .normal)

        UserManager.shared.add(user: user)
    }
}

